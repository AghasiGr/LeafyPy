import LeafyPy as lf

lf.cam(0)