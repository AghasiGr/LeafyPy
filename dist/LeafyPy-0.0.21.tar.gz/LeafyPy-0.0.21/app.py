import LeafyPi as LP

print(LP.add_numbers(5, 5))