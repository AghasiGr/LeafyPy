LeafyPi
A Python library for general tasks